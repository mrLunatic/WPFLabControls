﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Shapes;
using System.ComponentModel;

using LabControls.Common;

namespace LabControls
{

    public class Tick : FrameworkElement, INotifyPropertyChanged
    {

        #region Properties



        public Size Size
        {
            get { return (Size)GetValue(SizeProperty); }
            set { SetValue(SizeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Size.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SizeProperty =
            DependencyProperty.Register("Size", typeof(Size), typeof(Tick), new PropertyMetadata(new Size(1, 5), UpdateGeometryCallback));

        static void UpdateGeometryCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var model = d as Tick;
            model.UpdateGeometry();
        }




        public Brush Fill
        {
            get { return (Brush)GetValue(FillProperty); }
            set { SetValue(FillProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Fill.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FillProperty =
            DependencyProperty.Register("Fill", typeof(Brush), typeof(Tick), new PropertyMetadata(new SolidColorBrush(Colors.Black)));




        public Brush Stroke
        {
            get { return (Brush)GetValue(StrokeProperty); }
            set { SetValue(StrokeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Stroke.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty StrokeProperty =
            DependencyProperty.Register("Stroke", typeof(Brush), typeof(Tick), new PropertyMetadata(new SolidColorBrush(Colors.Black)));




        public double Thickness
        {
            get { return (double)GetValue(ThicknessProperty); }
            set { SetValue(ThicknessProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Thickness.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ThicknessProperty =
            DependencyProperty.Register("Thickness", typeof(double), typeof(Tick), new PropertyMetadata(0.5));



        public ShapeType Type
        {
            get { return (ShapeType)GetValue(TypeProperty); }
            set { SetValue(TypeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Type.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TypeProperty =
            DependencyProperty.Register("Type", typeof(ShapeType), typeof(Tick), new PropertyMetadata(ShapeType.Rectangle, UpdateGeometryCallback));

        

        public Geometry Geometry
        {
            get
            {
                return geometry;
            }
            private set
            {
                geometry = value;
                OnPropertyChanged("Geometry");
            }
        }
        Geometry geometry = Utilities.CreateGeometry(ShapeType.Rectangle, new Size(2, 5));

        #endregion


        public Tick()
        { }

        #region Methods

        public FrameworkElement CreateTick()
        {
            var path = new Path();

            var StrokeBinding = new Binding("Stroke");
            StrokeBinding.Source = this;
            path.SetBinding(Path.StrokeProperty, StrokeBinding);

            var FillBinding = new Binding("Fill");
            FillBinding.Source = this;
            path.SetBinding(Path.FillProperty, FillBinding);

            var ThicknessBinding = new Binding("Thickness");
            ThicknessBinding.Source = this;
            path.SetBinding(Path.StrokeThicknessProperty, ThicknessBinding);

            var GeometryBinding = new Binding("Geometry");
            GeometryBinding.Source = this;
            path.SetBinding(Path.DataProperty, GeometryBinding);

            return path;

           // return Utilities.CreateShape(Type, Size, Stroke, Thickness, Fill);
        }



        private void UpdateGeometry()
        {
            Geometry = Utilities.CreateGeometry(Type, Size);
        }

        #endregion

        public event PropertyChangedEventHandler PropertyChanged;

        void OnPropertyChanged(string PropertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(PropertyName));
        }
    }
}
