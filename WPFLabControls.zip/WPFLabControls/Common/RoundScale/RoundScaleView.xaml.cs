﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;


namespace LabControls.Common
{
    /// <summary>
    /// Логика взаимодействия для RoundScale.xaml
    /// </summary>
    public partial class RoundScaleView : ScaleView
    {
        /*

        #region Fields

        /// <summary>
        /// List of drawn major stamps.
        /// </summary>
        List<FrameworkElement> xamlMajorTicks = new List<FrameworkElement>();

        /// <summary>
        /// List of drawn minor stamps.
        /// </summary>
        List<FrameworkElement> xamlMinorTicks = new List<FrameworkElement>();

        /// <summary>
        /// List of drawn values
        /// </summary>
        List<FrameworkElement> xamlLabels = new List<FrameworkElement>();


        FrameworkElement ramp;


        #endregion Fields


        public RoundScaleView()
        {
            InitializeComponent();

            //ScaleModel.LabelsUpdate += LabelsUpdate;
            //ScaleModel.MinorTickUpdate += MinorTicksUpdate;
            //ScaleModel.MajorTicksUpdate += MajorTicksUpdate;

           // PointerModel = new RoundPointerModel();


            //PointerModel.Changed += PointerModel_Changed;



            Loaded += RoundScale_Loaded;
            
        }
        void RoundScale_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateScale(true); 
        }

        #region Dependency Properties

        public static readonly DependencyProperty MajorTickModelProperty = DependencyProperty.Register(
            "MajorTickModel", typeof(Tick), typeof(RoundScaleView), new PropertyMetadata(MajorTickModelChangedCallback));
        public Tick MajorTickModel
        {
            get
            {
                return (Tick)this.GetValue(MajorTickModelProperty);
            }
            set
            {
                this.SetValue(MajorTickModelProperty, value);
            }
        }
        static void MajorTickModelChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e) 
        {
            var scale = d as RoundScaleView;
            var newModel = e.NewValue as Tick;
            var oldModel = e.OldValue as Tick;

            if (oldModel != null)
                oldModel.PropertyChanged -= scale.MajorTickModel_PropertyChanged;

            if (newModel != null)
                newModel.PropertyChanged += scale.MajorTickModel_PropertyChanged;

            scale.UpdateMajorTicks(true);
            scale.UpdateLabels(true);
        }

        void MajorTickModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName.Equals("Geometry"))
                UpdateMajorTicks(true);
        }

        void MinorTickModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName.Equals("Geometry"))
                UpdateMinorTicks(true);
        }

        public static readonly DependencyProperty MinorTickModelProperty = DependencyProperty.Register(
            "MinorTickModel", typeof(Tick), typeof(RoundScaleView), new PropertyMetadata(MinorTickModelChangedCallback));
        public Tick MinorTickModel
        {
            get
            {
                return (Tick)this.GetValue(MinorTickModelProperty);
            }
            set
            {
                this.SetValue(MinorTickModelProperty, value);
            }
        }
        static void MinorTickModelChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            var newModel = e.NewValue as Tick;
            var oldModel = e.OldValue as Tick;

            if (oldModel != null)
                oldModel.PropertyChanged -= scale.MinorTickModel_PropertyChanged;

            if (newModel != null)
                newModel.PropertyChanged += scale.MinorTickModel_PropertyChanged;

            scale.UpdateMinorTicks(true);
        }

        public static readonly DependencyProperty ScaleModelProperty = DependencyProperty.Register(
            "ScaleModel", typeof(Scale), typeof(RoundScaleView), new PropertyMetadata(ScaleModelChangedCallback));
        public Scale ScaleModel
        {
            get
            {
                return (Scale)this.GetValue(ScaleModelProperty);
            }
            set
            {
                this.SetValue(ScaleModelProperty, value);
            }
        }
        static void ScaleModelChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            var oldModel = e.OldValue as Scale;
            var newModel = e.NewValue as Scale;

            if (oldModel != null)
            {
                oldModel.LabelsUpdate -= scale.LabelsUpdate;
                oldModel.MinorTickUpdate -= scale.MinorTicksUpdate;
                oldModel.MajorTicksUpdate -= scale.MajorTicksUpdate;
            }

            if (newModel != null)
            {
                newModel.LabelsUpdate += scale.LabelsUpdate;
                newModel.MinorTickUpdate += scale.MinorTicksUpdate;
                newModel.MajorTicksUpdate += scale.MajorTicksUpdate;
            }

            scale.UpdateScale(true);
        }

        public static readonly DependencyProperty RadiusProperty = DependencyProperty.Register(
            "Radius", typeof(double), typeof(RoundScaleView), new PropertyMetadata(100.0, RadiusChangedCallback, RadiusCoerceCallback));
        public double Radius
        {
            get
            {
                return (double)this.GetValue(RadiusProperty);
            }
            set
            {
                this.SetValue(RadiusProperty, value);
            }
        }
        static void RadiusChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            scale.UpdateScale(false);
        }
        static object RadiusCoerceCallback(DependencyObject d, object value)
        {
            double Value = (double)value;

            if ((Value <20) || double.IsNaN(Value) || double.IsInfinity(Value))
                Value = 20;

            return Value;
        }

        public static readonly DependencyProperty LabelPositionProperty = DependencyProperty.Register(
            "LabelPosition", typeof(Position), typeof(RoundScaleView), new PropertyMetadata(Position.Top, LabelPositionChangedCallback));
        public Position LabelPosition
        {
            get
            {
                return (Position)this.GetValue(LabelPositionProperty);
            }
            set
            {
                this.SetValue(LabelPositionProperty, value);
            }
        }
        static void LabelPositionChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            scale.UpdateLabels(false); ;
        }

        public static readonly DependencyProperty MajorTickPositionProperty = DependencyProperty.Register(
            "MajorTickPosition", typeof(Position), typeof(RoundScaleView), new PropertyMetadata(Position.Top, MajorTickPositionChangedCallback));
        public Position MajorTickPosition
        {
            get
            {
                return (Position)this.GetValue(MajorTickPositionProperty);
            }
            set
            {
                this.SetValue(MajorTickPositionProperty, value);
            }
        }
        static void MajorTickPositionChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            scale.UpdateLabels(false);
            scale.UpdateMajorTicks(false); 
        }

        public static readonly DependencyProperty MinorTickPositionProperty = DependencyProperty.Register(
            "MinorTickPosition", typeof(Position), typeof(RoundScaleView), new PropertyMetadata(Position.Top, MinorTickPositionChangedCallback));
        public Position MinorTickPosition
        {
            get
            {
                return (Position)this.GetValue(MinorTickPositionProperty);
            }
            set
            {
                this.SetValue(MinorTickPositionProperty, value);
            }
        }
        static void MinorTickPositionChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            scale.UpdateMinorTicks(false);
        }

        public static readonly DependencyProperty RampFillProperty = DependencyProperty.Register(
            "RampFill", typeof(Brush), typeof(RoundScaleView), new PropertyMetadata(new SolidColorBrush( Colors.Black), RampFillChangedCallback));
        public Brush RampFill
        {
            get
            {
                return (Brush)this.GetValue(RampFillProperty);
            }
            set
            {
                this.SetValue(RampFillProperty, value);
            }
        }
        static void RampFillChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            scale.UpdateRamp();
        }

        public static readonly DependencyProperty RampThicknessProperty = DependencyProperty.Register(
            "RampThickness", typeof(double), typeof(RoundScaleView), new PropertyMetadata(0.5, RampThicknessChangedCallback));
        public double RampThickness
        {
            get
            {
                return (double)this.GetValue(RampThicknessProperty);
            }
            set
            {
                this.SetValue(RampThicknessProperty, value);
            }
        }
        static void RampThicknessChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            scale.UpdateRamp();
        }

        public static readonly DependencyProperty RampPositionProperty = DependencyProperty.Register(
            "RampPosition", typeof(Position), typeof(RoundScaleView), new PropertyMetadata(Position.Center, RampPositionChangedCallback));
        public Position RampPosition
        {
            get
            {
                return (Position)this.GetValue(RampPositionProperty);
            }
            set
            {
                this.SetValue(RampPositionProperty, value);
            }
        }
        static void RampPositionChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var scale = d as RoundScaleView;
            scale.UpdateRamp();
        }

        #endregion


        #region Methods

        void LabelsUpdate(object sender, LabelsUpdateArgs e)
        {
            UpdateLabels(false);
        }
        void MinorTicksUpdate(object sender, TicksUpdateArgs e)
        {
            UpdateMinorTicks(true);
        }
        void MajorTicksUpdate(object sender, TicksUpdateArgs e)
        {
            UpdateMajorTicks(false);
            UpdateRamp();
        }

        void UpdateScale(bool Forced )
        {

            UpdateMajorTicks(Forced);
            UpdateLabels(Forced);
            UpdateMinorTicks(Forced);
            UpdateRamp();
        }

        void UpdateMajorTicks(bool Forced)
        {
            if ((ScaleModel != null) && (MajorTickModel != null))
            {
                if ((ScaleModel.MajorTicks.Length != this.xamlMajorTicks.Count) || Forced)
                {
                    ClearXamlMajorTicks();
                    CreateXamlMajorTicks();

                    ScaleCanvas.UpdateLayout();
                }

                foreach (var xamlTick in xamlMajorTicks)
                    ConfigureMajorTick(xamlTick);
            }
            else
            {
                ClearXamlMajorTicks();
            }
        }
        void CreateXamlMajorTicks()
        {
            foreach (var modelTick in ScaleModel.MajorTicks)
            {
                var xamlTick = MajorTickModel.CreateTick();

                xamlTick.SetValue(Canvas.ZIndexProperty, 2);
                xamlTick.DataContext = modelTick;

                xamlMajorTicks.Add(xamlTick);

                ScaleCanvas.Children.Add(xamlTick);
            }
        }
        void ClearXamlMajorTicks()
        {
            foreach (var xamlTick in this.xamlMajorTicks)
                ScaleCanvas.Children.Remove(xamlTick);

            this.xamlMajorTicks.Clear();
        }


        void UpdateLabels(bool Forced)
        {
            if ( (ScaleModel != null) && (MajorTickModel != null) )
            {

                if ((ScaleModel.Labels.Length != this.xamlLabels.Count) || Forced)
                {
                    ClearXamlLabels();
                    CreateXamlLabels();
                }
                else
                    for (int i = 0; i < xamlLabels.Count; i++)
                        ((TextBlock)xamlLabels[i]).Text = ScaleModel.Labels[i].String;

                ScaleCanvas.UpdateLayout();

                foreach (var xamlLabel in xamlLabels)
                    ConfigureXamlLabel(xamlLabel);
            }
            else
            {
                ClearXamlLabels();
            }
            
        }
        private void CreateXamlLabels()
        {
            foreach (var modelLabel in ScaleModel.Labels)
            {
                TextBlock xamlLabel = new TextBlock();
                xamlLabel.TextAlignment = TextAlignment.Center;
                xamlLabel.VerticalAlignment = VerticalAlignment.Center;
                xamlLabel.HorizontalAlignment = HorizontalAlignment.Center;

                xamlLabel.Text = modelLabel.String;
                xamlLabel.DataContext = modelLabel;
                xamlLabel.SetValue(Canvas.ZIndexProperty, 3);

                xamlLabels.Add(xamlLabel);
                ScaleCanvas.Children.Add(xamlLabel);
            }
        }
        private void ClearXamlLabels()
        {
            foreach (var xamlLabel in this.xamlLabels)
                ScaleCanvas.Children.Remove(xamlLabel);

            this.xamlLabels.Clear();
        }        
        

        void UpdateMinorTicks(bool Forced)
        {
            if ( (ScaleModel != null) && (MinorTickModel != null) )
            {
                if ((ScaleModel.MinorTicks.Length != this.xamlMinorTicks.Count) || Forced)
                {
                    ClearXamlMinorTicks();
                    CreateXamlMinorTicks();

                    ScaleCanvas.UpdateLayout();
                }


                foreach (var xamlTick in xamlMinorTicks)
                    ConfigureMinorTick(xamlTick);
            }
            else
            {
                ClearXamlMinorTicks();
            }
        }
        void CreateXamlMinorTicks()
        {
            foreach (var modelTick in ScaleModel.MinorTicks)
            {
                var xamlTick = MinorTickModel.CreateTick();

                xamlTick.SetValue(Canvas.ZIndexProperty, 1);
                xamlTick.DataContext = modelTick;

                xamlMinorTicks.Add(xamlTick);
                ScaleCanvas.Children.Add(xamlTick);
            }
        }
        void ClearXamlMinorTicks()
        {
            foreach (var xamlTick in this.xamlMinorTicks)
                ScaleCanvas.Children.Remove(xamlTick);

            this.xamlMinorTicks.Clear();
        }
        



        void UpdateRamp()
        {
            if (ramp != null)
                ScaleCanvas.Children.Remove(ramp);

            if (ScaleModel != null)
            {
                ramp = CreateRamp();
                ScaleCanvas.Children.Add(ramp);
            }
        }
*/

       protected override FrameworkElement CreateRamp()
        {
            var rampRadius = 0.0;

            switch (RampPosition)
            {
                case Position.Top:
                    rampRadius = Radius + RampThickness / 2;
                    break;
                case Position.Center:
                    rampRadius = Radius;
                    break;
                case Position.Bottom: 
                    rampRadius = Radius - RampThickness / 2; 
                    break;
            }

            var arcGeometry = Utilities.CreateArc(ScaleModel.ScaledMin, ScaleModel.ScaledMax, rampRadius);
            var arcPath = new Path();
            arcPath.Stroke = RampFill;
            arcPath.StrokeThickness = RampThickness;
            arcPath.Data = arcGeometry;

            arcPath.SetValue(Canvas.ZIndexProperty, -1);


            return arcPath;
        }
protected override void ConfigureMinorTick(FrameworkElement Tick)
        {
            var Group = new TransformGroup();

            var Translation = new TranslateTransform();
            Group.Children.Add(Translation);

            var Rotation = new RotateTransform();
            Group.Children.Add(Rotation);

            var scaleTick = Tick.DataContext as ScaleTick;

            if (scaleTick == null)
                return ;

            Translation.X = 0;

           switch (MinorTickPosition)
           {
               case Position.Top: 
                   Translation.Y = -Radius - MinorTickModel.Size.Height/2; 
                   break;
               case Position.Center: 
                   Translation.Y = -Radius; 
                   break;
               case Position.Bottom: 
                   Translation.Y = -Radius + MinorTickModel.Size.Height / 2; 
                   break;
           }


            Rotation.Angle = ScaleModel.ScaleForward(scaleTick.Value);

            Tick.RenderTransform = Group;

        }
protected override void ConfigureXamlLabel(FrameworkElement label)
        {
            var Transform = new TranslateTransform();
            var modelLabel = label.DataContext as ScaleLabel;

            if (modelLabel == null)
                return;

            var RadX = Radius;
            var RadY = Radius;

            double shift = 0.0;

            if (MajorTickModel != null)
            {
                shift = MajorTickModel.Size.Height;
            }
            switch (LabelPosition)
            {
                case Position.Top:
                    RadX += shift + label.ActualWidth / 2 + 10;
                    RadY += shift + label.ActualHeight / 2 + 5;  
                    break;
                case Position.Bottom:
                    RadX -= shift + label.ActualWidth / 2 + 10;
                    RadY -= shift + label.ActualHeight / 2 + 5; ;
                    break;
                case Position.Center: break;
            }

            var Angle = ScaleModel.ScaleForward(modelLabel.Value) * Math.PI / 180;

            Transform.X = RadX * Math.Sin(Angle) - label.ActualWidth / 2;
            Transform.Y = -RadY * Math.Cos(Angle) - label.ActualHeight / 2;

            label.RenderTransform = Transform;

        }
protected override void ConfigureMajorTick(FrameworkElement Tick)
        {
            var Group = new TransformGroup();
            
            var Translation = new TranslateTransform();
            Group.Children.Add(Translation);

            var Rotation = new RotateTransform();
            Group.Children.Add(Rotation);

            var scaleTick = Tick.DataContext as ScaleTick;

            if (scaleTick == null)
                return;

            Translation.X = 0;


            switch (MajorTickPosition)
            {
                case Position.Top: 
                    Translation.Y = -Radius - MajorTickModel.Size.Height / 2; 
                    break;
                case Position.Center: 
                    Translation.Y = -Radius; 
                    break;
                case Position.Bottom: 
                    Translation.Y = -Radius + MajorTickModel.Size.Height / 2; 
                    break;
            }

            Rotation.Angle = ScaleModel.ScaleForward(scaleTick.Value);

            Tick.RenderTransform = Group;

        }


        //#endregion Methods
    }
    
}
